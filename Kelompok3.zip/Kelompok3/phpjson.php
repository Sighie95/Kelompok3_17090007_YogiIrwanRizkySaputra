<?php 
$link = mysqli_connect("localhost","root","");
mysqli_select_db($link,"test");

$json = '{"message": {';
$query = mysqli_query($link,"select * from message");
$json .= '"pesan": [ ';
while ($x = mysqli_fetch_array($query)) {
	$json .= '{';
	$json .= '"id":  "' .   $x['message_id'] . '",
				"user": "' . htmlspecialchars($x['user_name']) . '",
				"text": "' . htmlspecialchars($x['message']) . '",
				"time": "' . $x['post_time'] . '"
			},';
}
//hilangkan koma (,) di akhir
	$json = substr($json,0, strlen($json)-1);

// lengkapi penutup format JSON
	$json .= ']';
	$json .= '}}';

	echo $json;

 ?>